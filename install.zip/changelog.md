## v4.2.5
- Updated hosts file

## v4.2.4
- Updated hosts file

## v4.2.3
- Updated hosts file

## v4.2.3
- Updated hosts file

## v4.2.3
- Updated hosts file

## v1.2
- Updated hosts file
- Added more info to ``README.md``